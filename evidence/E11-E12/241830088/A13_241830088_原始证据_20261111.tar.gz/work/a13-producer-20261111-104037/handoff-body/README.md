# A13 independent report handoff

Verify SHA256SUMS before consuming. incremental-check.json and incremental-report.json are immutable producer originals. project.bundle contains handoff-base and handoff-target; clone it into a new project directory before B-side consumption.

This offline package is not a B13 acknowledgment. B-side outputs must be returned separately with their own hashes and receipt. No new API registration is implied by the preserved artifact URIs.
